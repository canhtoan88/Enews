module.exports = function(res) {
	res.send('Bạn phải đăng nhập để thực hiện chức năng này!')
}